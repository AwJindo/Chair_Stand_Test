package com.example.accelrationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ShowValuesFromHistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_values_from_history);
    }
}