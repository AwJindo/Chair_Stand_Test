package com.example.accelrationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AcceptTestValuesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accept_test_values);
    }
}