# AccelrationApp
 
// TODO Describe the application, usecase, how to use it etc
